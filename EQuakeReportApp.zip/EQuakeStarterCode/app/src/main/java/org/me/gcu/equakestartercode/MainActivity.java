//Andrew Little - S17082906

package org.me.gcu.equakestartercode;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;


public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    private ArrayList<String> earthquakes;
    private ListView listView;


    private TextView dataDisplay;
    private Button startButton;
    private String result = "";
    private String url1 = "";
    private String urlSource = "http://quakes.bgs.ac.uk/feeds/MhSeismology.xml";

    @Override
    protected void onCreate(Bundle savedInstanceState)  {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.e("MyTag", "in onCreate");
        // Set up the raw links to the graphical components
        Log.e("MyTag", "after startButton");
        // More Code goes here
        startProgress();
        Log.e("MyTag", "after startProgress");


        earthquakes = new ArrayList<>();

        earthquakes.addAll(earthquakes);

        listView = (ListView) findViewById(R.id.list);
        listView.setOnItemClickListener(this);

        ArrayAdapter adapter = new ArrayAdapter<String>(this,
                R.layout.activity_listview,earthquakes);

        if (adapter == null)
        {
            Log.e("MyTag","Adapter error");
        }

        // Assign adapter to ListView
        listView.setAdapter(adapter);


    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
            if (id == R.id.map) {
                Intent settingsItent = new Intent(this, MapActivity.class);
                startActivity(settingsItent);
                return true;
            }else{
                if (id == R.id.order) {
                    Intent settingsItent = new Intent(this, OrderActivity.class);
                    startActivity(settingsItent);
                    return true;
            }else{
                if (id == R.id.selectDate) {
                    Intent settingsItent = new Intent(this, DateActivity.class);
                    startActivity(settingsItent);
                    return true;
        }
        return super.onOptionsItemSelected(item);
    }}}

    //public void onClick(View aview) {
        //Log.e("MyTag", "in onClick");
        //startProgress();
        //Log.e("MyTag", "after startProgress");
   // }

    public void startProgress() {
        // Run network access on a separate thread;
        new Thread(new Task(urlSource)).start();
    } //

    // Need separate thread to access the internet resource over network
    // Other neater solutions should be adopted in later iterations.
    private class Task implements Runnable {
        private String url;

        public Task(String aurl) {
            url = aurl;
        }

        @Override
        public void run() {

            URL aurl;
            URLConnection yc;
            BufferedReader in = null;
            String inputLine = "";


            Log.e("MyTag", "in run");

            try {
                Log.e("MyTag", "in try");
                aurl = new URL(url);
                yc = aurl.openConnection();
                in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
                Log.e("MyTag", "after ready");
                //
                // Now read the data. Make sure that there are no specific hedrs
                // in the data file that you need to ignore.
                // The useful data that you need is in each of the item entries
                //
                while ((inputLine = in.readLine()) != null) {
                    result = result + inputLine;
                    //Log.e("MyTag",inputLine);

                }
                in.close();
            } catch (IOException ae) {
                Log.e("MyTag", "ioexception in run");
            }

            //
            // Now that you have the xml data you can parse it
            //
            LinkedList<EQuakeClass> alist = null;
            earthquakes = new ArrayList<String>();

            LinkedList<EQuakeClass> elist = null;
            elist = parseData(result);

            // Write list to Log for testing
            if (elist != null) {
                Log.e("MyTag", "List not null");
                int count = 0;
                for (Object o : elist) {
                    Log.e("MyTag", o.toString());
                    earthquakes.add(o.toString());
                    count = count + 1;
                }
                Log.e("My Tag", "List of Earthquakes: " + earthquakes.toString());
            } else {
                Log.e("MyTag", "List is null");
            }




            // Now update the TextView to display raw XML data
            // Probably not the best way to update TextView
            // but we are just getting started !

            MainActivity.this.runOnUiThread(new Runnable() {
                public void run() {
                    Log.d("UI thread", "I am the UI thread");
                    listView.getAdapter();
                }
            });
        }

    }

    private LinkedList<EQuakeClass> parseData(String dataToParse) {
        EQuakeClass earthquake = null;
        LinkedList<EQuakeClass> elist = null;
        try {
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(true);
            XmlPullParser xpp = factory.newPullParser();
            xpp.setInput(new StringReader(dataToParse));
            int eventType = xpp.getEventType();
            while (eventType != XmlPullParser.END_DOCUMENT) {
                // Found a start tag
                if (eventType == XmlPullParser.START_TAG) {
                    // Check which Tag we have
                    if (xpp.getName().equalsIgnoreCase("channel")) {
                        elist = new LinkedList<EQuakeClass>();
                    } else if (xpp.getName().equalsIgnoreCase("item")) {
                        Log.e("MyTag", "Item Start Tag found");
                        earthquake = new EQuakeClass();
                    } else if (xpp.getName().equalsIgnoreCase("description")) {
                        // Now just get the associated text
                        String temp = xpp.nextText();
                        // Do something with text
                        String[] arrOfStr = temp.split(";");
                        for (String a : arrOfStr) {
                            String[] tmpStr = a.split(":");
                            switch (tmpStr[0].trim()) {
                                case "Location":
                                    String location = tmpStr[1].trim();
                                    Log.e("MyTag", "Location is " + location);
                                    earthquake.setLocation(location);
                                    break;
                                case "Depth":
                                    String[] depthStr = tmpStr[1].trim().split("");
                                    String depth = depthStr[0].trim();
                                    float D = Float.parseFloat(depth);
                                    Log.e("MyTag", "Location is " + D);
                                    earthquake.setDepth(D);
                                    break;
                                case "Magnitude":
                                    String magnitude = tmpStr[1].trim();
                                    float mag = Float.parseFloat(magnitude);
                                    Log.e("MyTag", "Magnitude is " + mag);
                                    earthquake.setMagnitude(mag);
                                    break;
                            }
                        }

                    } else if (xpp.getName().equalsIgnoreCase("pubDate")) {
                        // Now just get the associated text
                        String temp = xpp.nextText();
                        // Do something with text
                        Log.e("MyTag", "Published date is  " + temp);
                        earthquake.setPubDate(temp);
                    } else
                        // Check which Tag we have
                        if (xpp.getName().equalsIgnoreCase("lat")) {
                            // Now just get the associated text
                            float temp = Float.parseFloat(xpp.nextText());
                            // Do something with text
                            Log.e("MyTag", "Latitude is " + temp);
                            earthquake.setLatitude(temp);
                        } else
                            // Check which Tag we have
                            if (xpp.getName().equalsIgnoreCase("long")) {
                                // Now just get the associated text
                                float temp = Float.parseFloat(xpp.nextText());
                                // Do something with text
                                Log.e("MyTag", "Longitude is " + temp);
                                earthquake.setLongitude(temp);
                            }
                } else if (eventType == XmlPullParser.END_TAG) {
                    if (xpp.getName().equalsIgnoreCase("item")) {
                        Log.e("MyTag", "earthquake is " + earthquake.toString());

                        elist.add(earthquake);
                    } else if (xpp.getName().equalsIgnoreCase("channel")) {
                        int size;
                        size = elist.size();
                        Log.e("MyTag", "Number of earthquakes is " + size);
                    }
                }
                // Get the next event
                eventType = xpp.next();
            } // End of while

        return elist;

        } catch (XmlPullParserException ae1) {
            Log.e("MyTag", "Parsing error" + ae1.toString());
        } catch (IOException ae1) {
            Log.e("MyTag", "IO error during parsing");
        }

        Log.e("MyTag", "End document");

        return elist;

    }

    public void onItemClick(AdapterView<?> parenr, View view, int position, long id)
    {
        // Do something if an item is clicked
    }


}
