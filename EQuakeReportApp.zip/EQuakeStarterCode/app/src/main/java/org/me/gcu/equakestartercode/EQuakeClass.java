//Andrew Little - S17082906

package org.me.gcu.equakestartercode;

public class EQuakeClass {

    private float magnitude;
    private double depth;
    private String pubDate;
    private String location;
    private float latitude;
    private float longitude;


    public EQuakeClass()
    {
        magnitude = 0;
        depth = 0;
        pubDate = "";
        location = "";
        latitude = 0;
        longitude = 0;
    }

    public EQuakeClass( float eMagnitude, double eDepth, String ePubDate, String eLocation, float eLatitude, float eLongitude)
    {

        magnitude = eMagnitude;
        depth = eDepth;
        pubDate= ePubDate;
        location = eLocation;
        latitude = eLatitude;
        longitude = eLongitude;
    }



    public float getMagnitude()
    {
        return magnitude;
    }

    public void setMagnitude(float eMagnitude) { magnitude = eMagnitude;}

    public double getDepth()
    {
        return depth;
    }

    public void setDepth(double eDepth){ depth = eDepth;    }

    public String getPubDate()
    {
        return pubDate;
    }

    public void setPubDate(String ePubDate) {pubDate = ePubDate;}

    public String getLocation()
    {
        return location;
    }

    public void setLocation(String eLocation) {location = eLocation;}

    public float getLatitude()
    {
        return latitude;
    }

    public void setLatitude(float eLatitude) { latitude = eLatitude;}

    public float getLongitude()
    {
        return longitude;
    }

    public void setLongitude(float eLongitude) { longitude = eLongitude;}

    public String toString()
    {
        String temp;

        temp = "Location is " + location + " " + ", Magnitude is " +magnitude + " " +  ", Date is " + pubDate + " " +  ", Depth is " +depth + " "+ "k" +  ", Coordinates are " +latitude + " " + longitude;

        return temp;
    }


} // End of class
