//Andrew Little - S1708206

package org.me.gcu.equakestartercode;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Map;

public class OrderActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.order_main);
        Log.e("MyTag", "in onCreate");
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_order, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.home) {
            Intent settingsItent = new Intent(this, MainActivity.class);
            startActivity(settingsItent);
            return true;
        }else{
            if (id == R.id.map) {
                Intent settingsItent = new Intent(this, MapActivity.class);
                startActivity(settingsItent);
                return true;
            }else{
                if (id == R.id.selectDate) {
                    Intent settingsItent = new Intent(this, DateActivity.class);
                    startActivity(settingsItent);
                    return true;
                }
                return super.onOptionsItemSelected(item);
            }}}
}
